$(".zhangmu").click(function(){
    $(".mengxiang").css("display","block");
    $(".meng").css("display","block")
});
$(".quxiao").click(function(){
    $(".meng").css("display","none");
    $(".mengxiang").css("display","none")
})
