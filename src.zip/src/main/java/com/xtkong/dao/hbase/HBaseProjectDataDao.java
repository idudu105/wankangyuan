package com.xtkong.dao.hbase;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.filter.BinaryComparator;
import org.apache.hadoop.hbase.filter.FilterList;
import org.apache.hadoop.hbase.filter.PrefixFilter;
import org.apache.hadoop.hbase.filter.SingleColumnValueFilter;
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp;
import org.apache.hadoop.hbase.filter.FilterList.Operator;
import org.apache.hadoop.hbase.util.Bytes;

import com.xtkong.model.SourceField;
import com.xtkong.service.PhoenixClient;
import com.xtkong.util.ConstantsHBase;
import com.xtkong.util.HBaseDB;

public class HBaseProjectDataDao {
	public static String getSourceDataId(String cs_id, String oldSourceDataId, String p_id) {
		String sourceDataId = null;
		try {
			String tableName = ConstantsHBase.TABLE_PREFIX_SOURCE_ + cs_id;
			HBaseDB db = HBaseDB.getInstance();
			Table table = db.getTable(tableName);
			Scan scan = new Scan();
			FilterList filterList = new FilterList(Operator.MUST_PASS_ALL);
			filterList.addFilter(new SingleColumnValueFilter(Bytes.toBytes(ConstantsHBase.FAMILY_INFO),
					Bytes.toBytes(ConstantsHBase.QUALIFIER_SOURCEDATAID), CompareOp.EQUAL,
					new BinaryComparator(Bytes.toBytes(oldSourceDataId))));
			filterList.addFilter(new SingleColumnValueFilter(Bytes.toBytes(ConstantsHBase.FAMILY_INFO),
					Bytes.toBytes(ConstantsHBase.QUALIFIER_PROJECT), CompareOp.EQUAL,
					new BinaryComparator(Bytes.toBytes(p_id))));
			scan.setFilter(filterList);
			ResultScanner resultScanner = table.getScanner(scan);
			Iterator<Result> iterator = resultScanner.iterator();
			if (iterator.hasNext()) {
				Result result = iterator.next();
				if (!result.isEmpty()) {
					// 获取行键sourceDataId
					sourceDataId = Bytes.toString(result.getRow());
				}
			}
			resultScanner.close();
			table.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sourceDataId;
	}

	public static List<List<String>> getFormatNodesByTypes(String cs_id, String sourceDataId, List<String> ft_ids) {
		List<List<String>> formatNodes = new ArrayList<>();
		try {
			HBaseDB db = HBaseDB.getInstance();
			Table table = db.getTable(ConstantsHBase.TABLE_PREFIX_NODE_ + cs_id);
			Scan scan = new Scan();
			scan.addFamily(Bytes.toBytes(ConstantsHBase.FAMILY_INFO));

			FilterList filterList = new FilterList(Operator.MUST_PASS_ONE);
			for (String ft_id : ft_ids) {
				FilterList filter = new FilterList(Operator.MUST_PASS_ALL);
				filter.addFilter(new PrefixFilter(Bytes.toBytes(sourceDataId + "_" + ft_id + "_")));
				filter.addFilter(new SingleColumnValueFilter(Bytes.toBytes(ConstantsHBase.FAMILY_INFO),
						Bytes.toBytes(ConstantsHBase.QUALIFIER_FORMATTYPE), CompareOp.EQUAL,
						new BinaryComparator(Bytes.toBytes(ft_id))));
				filterList.addFilter(filter);
			}
			scan.setFilter(filterList);
			ResultScanner resultScanner = table.getScanner(scan);
			Iterator<Result> iterator = resultScanner.iterator();
			while (iterator.hasNext()) {
				Result result = iterator.next();
				if (!result.isEmpty()) {
					List<String> formatNode = new ArrayList<>();
					// 获取formatNodeId,ft_id,节点名
					String rowkey = Bytes.toString(result.getRow());
					String ft_id = Bytes.toString(result.getValue(Bytes.toBytes(ConstantsHBase.FAMILY_INFO),
							Bytes.toBytes(ConstantsHBase.QUALIFIER_FORMATTYPE)));
					String nodeName = Bytes.toString(result.getValue(Bytes.toBytes(ConstantsHBase.FAMILY_INFO),
							Bytes.toBytes(ConstantsHBase.QUALIFIER_NODENAME)));
					formatNode.add(rowkey);
					formatNode.add(ft_id);
					formatNode.add(nodeName);
					formatNodes.add(formatNode);
				}
			}
			resultScanner.close();
			table.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return formatNodes;

	}

	@SuppressWarnings("unchecked")
	public static boolean addProjectTypes(String cs_id, String sourceDataId, List<String> ft_ids,List<List<String>> formatNodes) {
		try {
			Boolean b = true;
			for (List<String> formatNode : formatNodes) {
				try {
					String oldFormatNodeId = formatNode.get(0);
					String ft_id = formatNode.get(1);
					String nodeName = formatNode.get(2);
					if (oldFormatNodeId != null) {
						String tableStr = ConstantsHBase.TABLE_PREFIX_FORMAT_ + cs_id + "_" + ft_id;
						Map<String, Map<String, Object>> records = PhoenixClient
								.select("SELECT  FROM \"" + tableStr + "\" WHERE ID='" + oldFormatNodeId + "'");
						List<String> head = (List<String>) records.get("records").get("head");
						List<List<String>> datas = (List<List<String>>) records.get("records").get("data");

						String formatNodeId = null;
						for (List<String> data : datas) {
							Map<String, String> formatFieldDatas = new HashMap<>();
							for (int i = 0; i < head.size(); i++) {
								if (!head.get(i).equals("ID")) {
									try {
										formatFieldDatas.put(head.get(i), data.get(i));
									} catch (Exception e) {
										continue;
									}
								}
							}
							formatNodeId = HBaseFormatNodeDao.insertFormatNode(cs_id, sourceDataId, ft_id, nodeName,
									formatFieldDatas);
						}
						if (formatNodeId != null) {
							records = PhoenixClient.select("SELECT  FROM \"" + tableStr + "\" WHERE ID!='" + oldFormatNodeId
									+ "' AND " + "\"" + ConstantsHBase.FAMILY_INFO + "\".\""
									+ ConstantsHBase.QUALIFIER_FORMATNODEID + "\"='" + oldFormatNodeId + "'  ");
							head = (List<String>) records.get("records").get("head");
							datas = (List<List<String>>) records.get("records").get("data");
							for (List<String> data : datas) {
								Map<String, String> formatFieldDatas = new HashMap<>();
								for (int i = 0; i < head.size(); i++) {
									if (!head.get(i).equals("ID")) {
										try {
											formatFieldDatas.put(head.get(i), data.get(i));
										} catch (Exception e) {
											continue;
										}
									}
								}
								HBaseFormatDataDao.insertFormatData(cs_id, ft_id, sourceDataId, formatNodeId,
										formatFieldDatas);
							}
						}
					}
				} catch (Exception e) {
					continue;
				}
			}
			return b;
		} catch (Exception e) {
			return false;
		}
	}
	
	public static boolean addProjectNodes(String cs_id, String sourceDataId, List<String> ft_ids,List<List<String>> formatNodes) {
		try {
			Boolean b = true;
			for (List<String> formatNode : formatNodes) {
				String oldFormatNodeId = formatNode.get(0);
				String ft_id = formatNode.get(1);
				String nodeName = formatNode.get(2);
				if (oldFormatNodeId != null) {
					String tableStr = ConstantsHBase.TABLE_PREFIX_FORMAT_ + cs_id + "_" + ft_id;
					Map<String, Map<String, Object>> records = PhoenixClient
							.select("SELECT  FROM \"" + tableStr + "\" WHERE ID='" + oldFormatNodeId + "'");
					List<String> head = (List<String>) records.get("records").get("head");
					List<List<String>> datas = (List<List<String>>) records.get("records").get("data");

					String formatNodeId = null;
					for (List<String> data : datas) {
						Map<String, String> formatFieldDatas = new HashMap<>();
						for (int i = 0; i < head.size(); i++) {
							if (!head.get(i).equals("ID")) {
								try {
									formatFieldDatas.put(head.get(i), data.get(i));
								} catch (Exception e) {
									continue;
								}
							}
						}
						formatNodeId = HBaseFormatNodeDao.insertFormatNode(cs_id, sourceDataId, ft_id, nodeName,
								formatFieldDatas);
					}
					if (formatNodeId != null) {
						records = PhoenixClient.select("SELECT  FROM \"" + tableStr + "\" WHERE ID!='" + oldFormatNodeId
								+ "' AND " + "\"" + ConstantsHBase.FAMILY_INFO + "\".\""
								+ ConstantsHBase.QUALIFIER_FORMATNODEID + "\"='" + oldFormatNodeId + "'  ");
						head = (List<String>) records.get("records").get("head");
						datas = (List<List<String>>) records.get("records").get("data");
						for (List<String> data : datas) {
							Map<String, String> formatFieldDatas = new HashMap<>();
							for (int i = 0; i < head.size(); i++) {
								if (!head.get(i).equals("ID")) {
									try {
										formatFieldDatas.put(head.get(i), data.get(i));
									} catch (Exception e) {
										continue;
									}
								}
							}
							HBaseFormatDataDao.insertFormatData(cs_id, ft_id, sourceDataId, formatNodeId,
									formatFieldDatas);
						}
					}
				}
			}
			return b;
		} catch (Exception e) {
			return false;
		}
	}
	
	
	public static boolean addProject(String p_id, String cs_id, String uid, List<String> sourceDataIds,
			List<SourceField> sourceFields) {
		try {
			HBaseDB db = HBaseDB.getInstance();
			String tableName = ConstantsHBase.TABLE_PREFIX_SOURCE_ + cs_id;
			String family = ConstantsHBase.FAMILY_INFO;
			Table table = db.getTable(tableName);
			List<Get> gets = new ArrayList<Get>();
			for (String sourceDataId : sourceDataIds) {
				gets.add(new Get(Bytes.toBytes(sourceDataId)));
			}
			// 存放批量操作的结果
			Result[] results = table.get(gets);
			Boolean b = true;
			for (Result result : results) {
				Long count = db.getNewId(ConstantsHBase.TABLE_GID, uid + "_" + cs_id, ConstantsHBase.FAMILY_GID_GID,
						ConstantsHBase.QUALIFIER_GID_GID_GID);
				String sourceDataId = uid + "_" + cs_id + "_" + count;
				Put put = new Put(Bytes.toBytes(sourceDataId));
				put.addColumn(Bytes.toBytes(family), Bytes.toBytes(ConstantsHBase.QUALIFIER_PUBLIC),
						Bytes.toBytes(ConstantsHBase.VALUE_PUBLIC_FALSE));
				put.addColumn(Bytes.toBytes(family), Bytes.toBytes(ConstantsHBase.QUALIFIER_PROJECT),
						Bytes.toBytes(String.valueOf(p_id)));

				String oldSourceDataId = Bytes.toString(result.getRow());
				put.addColumn(Bytes.toBytes(family), Bytes.toBytes(ConstantsHBase.QUALIFIER_SOURCEDATAID),
						Bytes.toBytes(String.valueOf(oldSourceDataId)));
				for (SourceField sourceField : sourceFields) {
					put.addColumn(Bytes.toBytes(family), Bytes.toBytes(String.valueOf(sourceField.getCsf_id())), result
							.getValue(Bytes.toBytes(family), Bytes.toBytes(String.valueOf(sourceField.getCsf_id()))));
				}
				if (db.putRow(tableName, put)) {

					List<List<String>> formatNodes = HBaseFormatNodeDao.getFormatNodes(cs_id, oldSourceDataId);
					for (List<String> formatNode : formatNodes) {
						String oldFormatNodeId = formatNode.get(0);
						String ft_id = formatNode.get(1);
						String nodeName = formatNode.get(2);
						if (oldFormatNodeId != null) {
							String tableStr = ConstantsHBase.TABLE_PREFIX_FORMAT_ + cs_id + "_" + ft_id;
							Map<String, Map<String, Object>> records = PhoenixClient
									.select("SELECT  FROM \"" + tableStr + "\" WHERE ID='" + oldFormatNodeId + "'");
							List<String> head = (List<String>) records.get("records").get("head");
							List<List<String>> datas = (List<List<String>>) records.get("records").get("data");

							String formatNodeId = null;
							for (List<String> data : datas) {
								Map<String, String> formatFieldDatas = new HashMap<>();
								for (int i = 0; i < head.size(); i++) {
									if (!head.get(i).equals("ID")) {
										try {
											formatFieldDatas.put(head.get(i), data.get(i));
										} catch (Exception e) {
											continue;
										}
									}
								}
								formatNodeId = HBaseFormatNodeDao.insertFormatNode(cs_id, sourceDataId, ft_id, nodeName,
										formatFieldDatas);
							}
							if (formatNodeId != null) {
								records = PhoenixClient.select("SELECT  FROM \"" + tableStr + "\" WHERE ID!='"
										+ oldFormatNodeId + "' AND " + "\"" + ConstantsHBase.FAMILY_INFO + "\".\""
										+ ConstantsHBase.QUALIFIER_FORMATNODEID + "\"='" + oldFormatNodeId + "'  ");
								head = (List<String>) records.get("records").get("head");
								datas = (List<List<String>>) records.get("records").get("data");
								for (List<String> data : datas) {
									Map<String, String> formatFieldDatas = new HashMap<>();
									for (int i = 0; i < head.size(); i++) {
										if (!head.get(i).equals("ID")) {
											try {
												formatFieldDatas.put(head.get(i), data.get(i));
											} catch (Exception e) {
												continue;
											}
										}
									}
									HBaseFormatDataDao.insertFormatData(cs_id, ft_id, sourceDataId, formatNodeId,
											formatFieldDatas);
								}
							}
						}
					}
				} else {
					b = false;
				}
			}
			table.close();
			return b;
		} catch (Exception e) {
			return false;
		}
	}
}
