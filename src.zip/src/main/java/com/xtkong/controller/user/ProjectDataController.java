package com.xtkong.controller.user;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.xtkong.service.ProjectDataService;
import com.liutianjun.pojo.User;
import com.xtkong.dao.hbase.HBaseFormatDataDao;
import com.xtkong.dao.hbase.HBaseFormatNodeDao;
import com.xtkong.dao.hbase.HBaseProjectDataDao;
import com.xtkong.dao.hbase.HBaseSourceDataDao;
import com.xtkong.model.FormatField;
import com.xtkong.model.FormatType;
import com.xtkong.service.FormatFieldService;
import com.xtkong.service.FormatTypeService;
import com.xtkong.service.SourceFieldService;
import com.xtkong.service.SourceService;
import com.xtkong.util.ConstantsHBase;

@Controller
@RequestMapping("/dataInpProject")
public class ProjectDataController {
	@Autowired
	SourceService sourceService;
	@Autowired
	SourceFieldService sourceFieldService;
	@Autowired
	FormatTypeService formatTypeService;
	@Autowired
	FormatFieldService formatFieldService;

	@Autowired
	ProjectDataService projectDataService;

	@RequestMapping("/insert")
	@ResponseBody
	public Map<String, Object> insert(HttpServletRequest request, HttpSession session, Integer p_id,
			String sourceDataIds, Integer cs_id) {
		User user = (User) request.getAttribute("user");
		Integer uid = user.getId();
		Map<String, Object> map = new HashMap<>();

		/*String[] source_data_id = sourceDataIds.split(",");
		for (int i = 0; i < source_data_id.length; i++) {			
			projectDataService.insert(new ProjectDataRelation(p_id, source_data_id[i]));
		}*/

//		Map<String, String> sourceFieldDatas = new HashMap<>();
//		sourceFieldDatas.put(ConstantsHBase.QUALIFIER_PROJECT, String.valueOf(p_id));
		List<String> old = projectDataService.select(p_id,cs_id);
		List<String> sourceDataIdList = new ArrayList<>();
		for (String sourceDataId : sourceDataIds.split(",")) {
			if (!old.contains(sourceDataId)) {
				sourceDataIdList.add(sourceDataId);
				projectDataService.insert(p_id, sourceDataId,cs_id);
			}
		}		
		boolean result=HBaseProjectDataDao.addProject(String.valueOf(p_id), String.valueOf(cs_id), String.valueOf(uid), sourceDataIdList,
				sourceFieldService.getSourceFields(cs_id));
		/*
		 * if(num == source_data_id.length){ map.put("result", true);
		 * map.put("message", "关系绑定成功！"); }else{ map.put("result", false);
		 * map.put("message",
		 * "共绑定"+num+"条关系，剩余"+(source_data_id.length-num)+"条关系绑定失败！"); }
		 */
		if (result) {
			map.put("result", true);
			map.put("message", "关系绑定成功！");
		}else{
			map.put("result", false);
			map.put("message", "关系绑定失败！");
		}

		return map;
	}

	@RequestMapping("/remove")
	@ResponseBody
	public Map<String, Object> remove(HttpSession session, Integer p_id, String sourceDataIds, String cs_id) {

		Map<String, Object> map = new HashMap<>();

		String[] source_data_id = sourceDataIds.split(",");
//		Map<String, String> sourceFieldDatas = new HashMap<>();
//		sourceFieldDatas.put(ConstantsHBase.QUALIFIER_PROJECT, String.valueOf("  "));
		for (int i = 0; i < source_data_id.length; i++) {
			projectDataService.remove(p_id, source_data_id[i],Integer.valueOf(cs_id));
//			HBaseSourceDataDao.updateSourceData(cs_id, source_data_id[i], sourceFieldDatas);
		}
		HBaseSourceDataDao.deleteSourceDatas(cs_id, sourceDataIds);
		/*
		 * if(num == source_data_id.length){ map.put("result", true);
		 * map.put("message", "关系绑定成功！"); }else{ map.put("result", false);
		 * map.put("message",
		 * "共绑定"+num+"条关系，剩余"+(source_data_id.length-num)+"条关系绑定失败！"); }
		 */
		map.put("result", true);
		map.put("message", "关系解绑定成功！");

		return map;
	}



	/**
	 * 添加格式类型数据
	 * 
	 * @param response
	 * @param cs_id
	 * @param oldSourceDataId
	 * @param ft_ids
	 */
	@RequestMapping("/formatType")
	public void formatType(HttpServletResponse response,String p_id, String cs_id, String oldSourceDataId, String ft_ids) {
		String sourceDataId=HBaseProjectDataDao.getSourceDataId(cs_id, oldSourceDataId, p_id);
		
		List<String> ft_idList=new ArrayList<>();
		for (String ft_idStr : ft_ids.split(",")) {
			ft_idList.add(ft_idStr);
		}
		List<List<String>> formatNodes =HBaseProjectDataDao.getFormatNodesByTypes(cs_id, oldSourceDataId, ft_idList);
		if (formatNodes!=null&&!formatNodes.isEmpty()) {
			
			HBaseProjectDataDao.addProjectTypes(cs_id, sourceDataId, ft_idList, formatNodes);
		}

	}

	/**
	 * 结点数据
	 * 
	 * @param response
	 * @param cs_id
	 * @param ft_id
	 * @param formatNodeId
	 */
	@RequestMapping("/formatNode")
	public void formatNode(HttpServletResponse response,String p_id, String cs_id, String ft_ids, String formatNodeIds) {
		
		
		
		
		response.setContentType("application/vnd.ms-excel");

		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFCellStyle style = workbook.createCellStyle();
		style.setAlignment(HorizontalAlignment.CENTER);
		HSSFSheet sheet;
		String[] formatNodeIdsStr = formatNodeIds.split(",");
		String[] ft_idsStr = ft_ids.split(",");

		for (int i = 0; i < ft_idsStr.length; i++) {
			// meta数据
			String ft_id = ft_idsStr[i];
			String formatNodeId = formatNodeIdsStr[i];
			FormatType formatType = formatTypeService.getFormatType(Integer.valueOf(ft_id));
			List<String> formatNode = HBaseFormatNodeDao.getFormatNodeById(cs_id, ft_id, formatNodeId);
			String nodeName = "";
			try {
				nodeName = formatNode.get(2);
			} catch (Exception e) {
				nodeName = "" + i;
			}
			sheet = workbook.createSheet(formatType.getFt_name() + "_" + nodeName + "_" + "公共数据");
			sheet = sheetFormatDatas(sheet, style, cs_id, ft_id, formatNodeId, ConstantsHBase.IS_meta_true);

			// data数据
			sheet = workbook.createSheet(formatType.getFt_name() + "_" + nodeName + "_" + "专属数据");
			sheet = sheetFormatDatas(sheet, style, cs_id, ft_id, formatNodeId, ConstantsHBase.IS_meta_false);
		}
		try {
			OutputStream output = response.getOutputStream();
			workbook.write(output);
			output.flush();
			output.close();
			workbook.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * 导出格式数据上传格式
	 * 
	 * @param response
	 * @param cs_id
	 */
	@RequestMapping("/formatDataModel")
	public void formatDataModel(HttpServletResponse response, String ft_id) {
		response.setContentType("application/vnd.ms-excel");
		/**
		 * 以下为生成Excel操作
		 */
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFCellStyle style = workbook.createCellStyle();
		style.setAlignment(HorizontalAlignment.CENTER);
		HSSFSheet sheet = workbook.createSheet("格式数据");
		sheet = sheetFormatFieldForm(sheet, style, ft_id, ConstantsHBase.IS_meta_false);
		try {
			OutputStream output = response.getOutputStream();
			workbook.write(output);
			output.flush();
			output.close();
			workbook.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 导出某格式数据
	 * 
	 * @param response
	 * @param cs_id
	 * @param ft_id
	 * @param formatDataIds
	 * @param type
	 *            1公共，0非公共
	 */
	@RequestMapping("/formatData")
	public void formatData(HttpServletResponse response, String cs_id, String ft_id, String formatDataIds) {
		response.setContentType("application/vnd.ms-excel");

		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFCellStyle style = workbook.createCellStyle();
		style.setAlignment(HorizontalAlignment.CENTER);
		HSSFSheet sheet = workbook.createSheet("格式数据");
		sheet = sheetFormatDataByIds(sheet, style, cs_id, ft_id, formatDataIds);
		try {
			OutputStream output = response.getOutputStream();
			workbook.write(output);
			output.flush();
			output.close();
			workbook.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private HSSFSheet sheetFormatFieldForm(HSSFSheet sheet, HSSFCellStyle style, String ft_id, Integer isMeta) {
		HSSFRow row = sheet.createRow((short) 0);
		// 设置表头
		List<FormatField> formatFields = formatFieldService.getFormatFieldsIs_meta(Integer.valueOf(ft_id), isMeta);
		HSSFCell cell = row.createCell(0);
		for (int i = 0; i < formatFields.size(); i++) {
			cell = row.createCell((i));
			cell.setCellValue(formatFields.get(i).getFf_name());
			cell.setCellStyle(style);
		}
		return sheet;
	}

	private HSSFSheet sheetFormatDataByIds(HSSFSheet sheet, HSSFCellStyle style, String cs_id, String ft_id,
			String formatDataIds) {
		HSSFRow row = sheet.createRow((short) 0);
		// 设置表头

		List<FormatField> formatFields = formatFieldService.getFormatFieldsForUser(Integer.valueOf(ft_id));
		if (formatFields.isEmpty()) {
			return sheet;
		}
		HSSFCell cell = row.createCell(0);
		for (int i = 0; i < formatFields.size(); i++) {
			cell = row.createCell((i));
			cell.setCellValue(formatFields.get(i).getFf_name());
			cell.setCellStyle(style);
		}

		List<List<String>> formatDatas = HBaseFormatDataDao.getFormatDataByIds(cs_id, ft_id, formatDataIds,
				formatFields);
		if (formatDatas.isEmpty()) {
			return sheet;
		}
		// 写入各条记录，每条记录对应Excel中的一行

		for (int iRow = 0; iRow < formatDatas.size(); iRow++) {
			row = sheet.createRow((short) iRow + 1);
			for (int j = 0; j < formatFields.size(); j++) {
				cell = row.createCell(j);
				cell.setCellValue(formatDatas.get(iRow).get(j));
				cell.setCellStyle(style);
			}
		}

		return sheet;
	}

	private HSSFSheet sheetFormatDatas(HSSFSheet sheet, HSSFCellStyle style, String cs_id, String ft_id,
			String formatNodeId, Integer isMeta) {
		HSSFRow row = sheet.createRow((short) 0);
		// 设置表头
		List<FormatField> formatFields = formatFieldService.getFormatFieldsIs_meta(Integer.valueOf(ft_id), isMeta);
		if (formatFields.isEmpty()) {
			return sheet;
		}

		HSSFCell cell = row.createCell(0);
		for (int i = 0; i < formatFields.size(); i++) {
			cell = row.createCell((i));
			cell.setCellValue(formatFields.get(i).getFf_name());
			cell.setCellStyle(style);
		}

		List<List<String>> formatDatas = HBaseFormatDataDao.getFormatDatas(cs_id, ft_id, formatNodeId, formatFields);
		if (formatDatas == null || formatDatas.isEmpty()) {
			return sheet;
		}
		// 写入各条记录，每条记录对应Excel中的一行
		if (isMeta.equals(ConstantsHBase.IS_meta_true)) {
			row = sheet.createRow((short) 1);
			for (int j = 0; j < formatFields.size(); j++) {
				cell = row.createCell(j);
				cell.setCellValue(formatDatas.get(0).get(j + 1));
				cell.setCellStyle(style);
			}
		} else {
			for (int iRow = 0; iRow < formatDatas.size(); iRow++) {
				row = sheet.createRow((short) iRow + 1);
				for (int j = 0; j < formatFields.size(); j++) {
					cell = row.createCell(j);
					cell.setCellValue(formatDatas.get(iRow).get(j + 1));
					cell.setCellStyle(style);
				}
			}
		}
		return sheet;
	}

}
