package com.xtkong.model;

public class UserData {

	private long uid;

	private String dataid;

	private long cs_id;

	public long getUid() {
		return uid;
	}

	public void setUid(long uid) {
		this.uid = uid;
	}

	public String getDataid() {
		return dataid;
	}

	public void setDataid(String dataid) {
		this.dataid = dataid;
	}

	public long getCs_id() {
		return cs_id;
	}

	public void setCs_id(long cs_id) {
		this.cs_id = cs_id;
	}


}
